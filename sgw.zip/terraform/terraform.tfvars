# =============================================================================
# Active Deployment Variables
# =============================================================================

project_name = "storage-gw"
environment  = "prod"

tags = {
  Environment = "prod"
  ManagedBy   = "terraform"
}

gcp_project              = "encoded-alpha-457108-e8"
gcp_region               = "us-central1"
source_vpc_ip_cidr_range = ["10.10.1.0/24"]

aws_region       = "us-east-1"
aws_vpc_cidr     = "10.0.0.0/16"
azs              = ["us-east-1a", "us-east-1b", "us-east-1c"]
public_subnets   = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
private_subnets  = ["10.0.4.0/24", "10.0.5.0/24", "10.0.6.0/24"]
database_subnets = []

gateway_instance_type = "m5.xlarge"
gateway_private_ip    = "10.0.4.150"
s3_bucket_name        = "gcp-simulated-storage-gateway-bucket"
smb_guest_password    = "GuestPass123!"

enable_least_privilege_iam = true
s3_force_destroy           = true
